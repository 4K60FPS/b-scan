<?php
echo shell_exec('whoami');
?>